import Foundation

class Language{
    
    class func currentLanguage ()->String{
        let def = UserDefaults.standard
        let lang = def.object(forKey: "AppleLanguages") as! NSArray
        let firstLang = lang.firstObject as! String
        return firstLang
    }
    
    class func setAppLanguage(lang:String){
        let def = UserDefaults.standard
        def.set([lang , currentLanguage()], forKey: "AppleLanguages")
        def.synchronize()
        
    }
}

