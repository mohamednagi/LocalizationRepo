import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func changeLanBu(_ sender: UIButton) {
        print(Language.currentLanguage())
        if Language.currentLanguage() == "ar" {
            Language.setAppLanguage(lang: "en")
            UIView.appearance().semanticContentAttribute = .forceLeftToRight
        }else {
            Language.setAppLanguage(lang: "ar")
            UIView.appearance().semanticContentAttribute = .forceRightToLeft
        }
        let window = (UIApplication.shared.delegate as? AppDelegate)?.window
        let sb = UIStoryboard(name: "Main", bundle: nil)
        window?.rootViewController = sb.instantiateViewController(withIdentifier: "Root")
        
       UIView.transition(with: window!, duration: 1, options: .transitionFlipFromLeft, animations: nil, completion: nil)
    }
}

